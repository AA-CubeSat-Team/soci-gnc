README.txt

Author:Devan Tormey
Date: Tuesday May 19th 2020 10:57PM

~~~~~~~~~~~~~~~~~~~~~~~
What is in here?
~~~~~~~~~~~~~~~~~~~~~~~
Same ol auto code format but now with the aact_autocoder.py

It's almost fully generalize. Just needs a few more things to work with input for whatever. Need to generate an "outputs.txt" 
to ge this to work the rest of the way

~~~~~~~~~~~~~~~~~~~~~~~
How run?
~~~~~~~~~~~~~~~~~~~~~~~

$: cd main_autocode
$: python aact_autocode.py
$: cd ..
$: make
$: ./main



